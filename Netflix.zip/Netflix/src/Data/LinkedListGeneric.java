package Data;

public class LinkedListGeneric<T extends Comparable<T>> {
	
	private NodeGeneric<T> head;
	
	public LinkedListGeneric() {
		
		head = null;
		
	}
	
	public boolean insert(T item) {
		
		boolean inserted;
		NodeGeneric<T> ptr,prev;
		inserted = false;
		ptr = head;
		prev = null;
		while(ptr != null && ptr.getData().compareTo(item) < 0) {
			
			
			prev = ptr;
			ptr = ptr.getNext();
			
		}
		
		if(ptr == null || !(ptr.getData().equals(item))) {
			
			inserted = true;
			NodeGeneric<T> newp = new NodeGeneric();
			newp.setData(item);
			newp.setNext(ptr);
			
			if(prev == null)
				head = newp;
			else 
				prev.setNext(newp);

			
		}
		return inserted;
			
	}
	
	private void printR(NodeGeneric<T> p) {
		
		if(p != null) {
			
			System.out.println(p.getData() );
			printR(p.getNext());
			
		}
		
	}
	
	public void printRecursive() {
		
		printR(head);
		System.out.println();
		
	}

}
