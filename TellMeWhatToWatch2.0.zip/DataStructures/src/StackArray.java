//stackArray of integers
public class StackArray {
	
	private static final int N = 3; //default array size
	private int top,sarray[];
	
//constructors
	public StackArray() { //Constructor by default	
		
		this(N);
	}
	
	public StackArray(int n) { //Constructor with n as the stack length
		
		top = 0;
		sarray = new int[n];
		
	}
	
//Value returning methods
	
	public boolean empty() { // Check if the stack is empty 
		
		return top <=0;
		
	}

	public boolean full() {
	
	return top >= sarray.length; //check if the stack is full
	
}
	
	public int pop() { //pop the top element from the stack
		if(empty()) 
			throw new RuntimeException("Stack is empty");
		top--;
		return sarray[top];
		
		
	}
	
	//void method
	
	public void push(int item) {
		if(full()) throw new RuntimeException("Stack is full");
		sarray[top]=item;
		top++;
		
		
	}

	public void showStack() {
		
		for(int i = 0;i<sarray.length;i++) {
			
			System.out.println(sarray[i]);
			
		}
		
	}


}
